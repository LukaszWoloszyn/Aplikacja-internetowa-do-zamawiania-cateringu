<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('shared.head', ['pageTitle' => 'Catering dietetyczny'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="start">
      <div id="carouselExampleCaptions" class="carousel slide">

        <div class="carousel-inner">
            <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
            <img src="<?php echo e(asset('storage/img/offer/'.$offer->image)); ?>" class="d-block mx-auto w-50" alt="...">
            <div class="carousel-caption d-none d-md-block">
              <h1 class="text-white"><?php echo e($offer->title); ?></h1>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <th scope="row" colspan="6">Brak ofert</th>

          <?php endif; ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>

      </div>
    </div>

    <div id="diety" class="container mt-5">
      <div class="row">
        <h1>Polecane diety: </h1>
      </div>
      <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-sm-6 col-lg-4  mb-4">
                <div class="card">
                    <img src="<?php echo e(asset('storage/img/offer/'.$offer->image)); ?>" class="card-img-top" width="50px" height="250px">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($offer->title); ?></h5>
                        <div class="table-responsive-sm">
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Śniadanie</th>
                                    <th scope="col">Obiad</th>
                                    <th scope="col">Kolacja</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                      <td><?php echo e($offer->breakfast); ?></td>
                                      <td><?php echo e($offer->dinner); ?></td>
                                      <td><?php echo e($offer->supper); ?></td>
                                  </tr>
                            </tbody>
                        </table>
                            <div class="mt-auto d-flex justify-content-between">
                                <a href="<?php echo e(route('recipes.main', ['id' => $offer->id])); ?>" class="btn btn-primary">Więcej szczegółów...</a>
                                <a href="<?php echo e(route('orders.create', ['offer_id' => $offer->id])); ?>" class="btn btn-success">Dodaj do koszyka</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Brak oferty.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/home.blade.php ENDPATH**/ ?>