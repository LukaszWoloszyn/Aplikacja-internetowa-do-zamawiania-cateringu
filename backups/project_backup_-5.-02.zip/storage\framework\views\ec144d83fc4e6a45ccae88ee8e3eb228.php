<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Catering dietetyczny'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h1>Utwórz zamówienie</h1>
                <form method="POST" action="<?php echo e(route('orders.store')); ?>" id="orderForm">
                    
                    <div class="form-group">
                        <label for="offer_id">Oferta</label>
                        <select name="offer_id" id="offer_id" class="form-control" required>
                            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($offer->id); ?>" data-week-price="<?php echo e($offer->price_week); ?>" data-month-price="<?php echo e($offer->price_month); ?>" <?php echo e($selectedOffer && $selectedOffer->id == $offer->id ? 'selected' : ''); ?>>
                                    <?php echo e($offer->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="duration">Czas trwania</label>
                        <select name="duration" id="duration" class="form-control" required>
                            <option value="week">Tydzień</option>
                            <option value="month">Miesiąc</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="total_price">Cena</label>
                        <input type="text" name="total_price" id="total_price" class="form-control" readonly>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Utwórz</button>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const offerSelect = document.getElementById('offer_id');
        const durationSelect = document.getElementById('duration');
        const totalPriceInput = document.getElementById('total_price');

        function calculateTotalPrice() {
            const selectedOption = offerSelect.options[offerSelect.selectedIndex];
            const weekPrice = parseFloat(selectedOption.getAttribute('data-week-price'));
            const monthPrice = parseFloat(selectedOption.getAttribute('data-month-price'));
            const duration = durationSelect.value;

            if (duration === 'week') {
                totalPriceInput.value = weekPrice;
            } else if (duration === 'month') {
                totalPriceInput.value = monthPrice;
            }
        }

        offerSelect.addEventListener('change', calculateTotalPrice);
        durationSelect.addEventListener('change', calculateTotalPrice);

        calculateTotalPrice(); // Initial calculation
    });
    </script>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/orders/create.blade.php ENDPATH**/ ?>