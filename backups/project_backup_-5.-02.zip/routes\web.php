<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OfferController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\RecipeController;
use Illuminate\Support\Facades\Route;

//strona głowna
Route::get('/home', [HomeController::class, 'home'])->name('home');

// to do konkretnego dania:
Route::controller(RecipeController::class)->group(function () {
    // Route::get('/recipes', 'main')->name('recipes.main1');
    Route::get('/offer/{id}', 'main')->name('recipes.main');
});

//wszystkie diety
Route::get('/all', [HomeController::class, 'main1'])->name('main1');

//przepis na danie
Route::get('/recip', [RecipeController::class, 'recip'])->name('recip');


//zamowienia dla admina
Route::get('/orders', [AccountController::class, 'order'])->name('order');

//tworzenie
Route::get('/create', [OfferController::class, 'create'])->name('admin.createOff');
Route::post('/store', [OfferController::class, 'store'])->name('admin.storeOff');


//edytowanie
Route::get('/admin/offers/edit', [OfferController::class, 'adminEdit'])->name('admin.offers.edit');
Route::put('/admin/offers/{id}', [OfferController::class, 'update'])->name('admin.offers.update');

//usuwanie
Route::delete('/offers/{id}', [OfferController::class, 'destroy'])->name('offers.destroy');
Route::get('/admin/offers', [OfferController::class, 'adminIndex'])->name('admin.offers.index');



//logowanie
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login.form');
Route::post('/login', [AuthController::class, 'login'])->name('login.authenticate');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');


Route::get('/admin/users/create', [AccountController::class, 'create'])->name('admin.users.create');
Route::post('/admin/users', [AccountController::class, 'store'])->name('admin.users.store');

Route::middleware(['auth'])->group(function () {
    Route::get('/user/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/user/orders/create/{offer_id?}', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/user/orders', [OrderController::class, 'store'])->name('orders.store');
});

// Przykład dla zalogowanych użytkowników
// Route::middleware(['auth'])->group(function () {
//     Route::get('/home', [HomeController::class, 'home'])->name('home');
// });


// Route::delete('/admin/offers/{id}', [OfferController::class, 'destroy'])->name('admin.offers.destroy');
// Route::put('/offers', [OfferController::class, 'adminUpdate'])->name('admin.offers.update');
// Route::get('/create', [OfferController::class, 'create'])->name('admin.createOff');
// Route::post('/recipes', [OfferController::class, 'create'])->name('admin.createOff');













