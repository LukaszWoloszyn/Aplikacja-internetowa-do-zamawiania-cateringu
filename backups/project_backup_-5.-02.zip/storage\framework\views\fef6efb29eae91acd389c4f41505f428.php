<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('shared.head', ['pageTitle' => 'Panel admina'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="cennik" class="container mt-5 mb-5">
    <div class="row">
        <h1>Tabela zamówień</h1>
    </div>
    <div class="table-responsive-sm">
      <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th scope="col">ID zamówienia</th>
                <th scope="col">Imię</th>
                <th scope="col">Nazwisko</th>
                <th scope="col">Email</th>
                <th scope="col">Numer telefonu</th>
                <th scope="col">Adres</th>
                
            </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                   <th scope="row"><?php echo e($order->id); ?></th>
                   <td><?php echo e($order->name); ?></td>
                   <td><?php echo e($order->last_name); ?></td>
                   <td><?php echo e($order->email); ?></td>
                   <td><?php echo e($order->phone_number); ?></td>
                   <td><?php echo e($order->address); ?></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                  <th scope="row" colspan="6">Brak wycieczek.</th>
               </tr>
          <?php endif; ?>
        </tbody>
    </table>
    </div>
  </div>

  

  </html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/admin/orders.blade.php ENDPATH**/ ?>