<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('shared.head', ['pageTitle' => 'Catering'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

  <div class="container my-5">
    <section class="mb-4">
    <h2>Przepis na danie główne z diety: <?php echo e($recipe->offers->title); ?></h2>
    <div class="row">
        <div class="col-md-4">
          <img src="<?php echo e(asset('storage/img/recipes/'.$recipe->image)); ?>" class="img-fluid" alt="danie">
        </div>
        <div class="col-md-8">
            <div class="d-flex align-items-center mb-3">
              <img src="<?php echo e(asset('storage/img/recipes/zegar.png')); ?>" alt="zegar" class="img-fluid" width="50px" height="50px">
              <label class="me-4">Czas: <?php echo e($recipe->time); ?> min</label>
              <img src="<?php echo e(asset('storage/img/recipes/pngegg_jasny.png')); ?>" alt="czlowiek" class="img-fluid" width="50px" height="50px">
            <label class="me-4">Ilość porcji: <?php echo e($recipe->servings); ?></label>
        </div>
        <h3>Składniki:</h3>
        <label><?php echo e($recipe->ingredients); ?></label>
      </div>
    </div>
  </section>
  <section>
    <h3>Przygotowanie:</h3>
    <label><?php echo e($recipe->instructions); ?></label>
  </section>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <th scope="row" colspan="6">Brak przepisów</th>

    <?php endif; ?>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-pk1E90Hszlw5EECMfTb/NwRQwFnCSdBsgBtXoZh0+ajMQ5eMf0D0xH9pZdz+7j2" crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/recipes/recip.blade.php ENDPATH**/ ?>