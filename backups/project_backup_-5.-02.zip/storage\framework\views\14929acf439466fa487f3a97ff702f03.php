<nav class="navbar navbar-expand-lg nav-bg">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Catering dietetyczny</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>">Start</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('recip')); ?>">Przepisy</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('main1')); ?>">Diety</a>
          </li>

          <?php if(Auth::check() && Auth::user()->admin): ?>
          
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.offers.edit')); ?>">Edytuj</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('admin.offers.index')); ?>">Usuń</a>
            </li>
          <?php endif; ?>

          <?php if(auth()->guard()->guest()): ?>
          <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('orders.index')); ?>">Zamówienia</a>
                    </li>
        <?php endif; ?>

        
        </ul>
        <ul class="navbar-nav mb-2 mb-lg-0">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login.form')); ?>">Zaloguj się</a>
                    </li>
                <?php else: ?>
                
                    <li class="nav-item">
                        <a class="nav-link" href="#"><?php echo e(Auth::user()->name); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Wyloguj się
                        </a>
                    </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?>
            </ul>
            
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/shared/navbar.blade.php ENDPATH**/ ?>