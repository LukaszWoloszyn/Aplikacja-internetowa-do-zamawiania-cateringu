<?php

namespace Database\Seeders;

use App\Models\Recipe;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;

class RecipeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Schema::withoutForeignKeyConstraints(function () {
            Recipe::truncate();
        });
        Recipe::truncate();
        Recipe::insert(
            [
                [
                    'title' => 'Przepis na naleśniki', 'time' => '30', 'servings' => '3', 'ingredients' => '1 szklanka mąki przennej, 2 jajka,
                    1,5 szklanki mleka, szczypta soli łyżka cukru', 'instructions' => 'W dużej misce wymieszaj mąkę pszeniczną, jajka, mleko,
                    sól i cukier, aż do uzyskania gładkiego ciasta. Pozwól ciastu odpocząć przez około 15 minut, aby mąka wchłonęła płyny.',
                    'image' => 'nalesniki.jpg', 'offers_id' => 1
                ],

                [
                    'title' => 'Przepis na jabłka', 'time' => '30', 'servings' => '3', 'ingredients' => '1 szklanka mąki przennej, 2 jajka,
                    1,5 szklanki mleka, szczypta soli łyżka cukru', 'instructions' => 'W dużej misce wymieszaj mąkę pszeniczną, jajka, mleko,
                    sól i cukier, aż do uzyskania gładkiego ciasta. Pozwól ciastu odpocząć przez około 15 minut, aby mąka wchłonęła płyny.',
                    'image' => 'pierogi1.jpg', 'offers_id' => 2
                ],
                [
                    'title' => 'Przepis na kanapki', 'time' => '30', 'servings' => '3', 'ingredients' => '1 szklanka mąki przennej, 2 jajka,
                    1,5 szklanki mleka, szczypta soli łyżka cukru', 'instructions' => 'W dużej misce wymieszaj mąkę pszeniczną, jajka, mleko,
                    sól i cukier, aż do uzyskania gładkiego ciasta. Pozwól ciastu odpocząć przez około 15 minut, aby mąka wchłonęła płyny.',
                    'image' => 'pierogi1.jpg', 'offers_id' => 2
                ],
            ]
        );

    }
}
