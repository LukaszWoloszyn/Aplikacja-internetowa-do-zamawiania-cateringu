<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('shared.head', ['pageTitle' => 'Catering'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="wycieczki" class="container mt-5 mb-5">
        <div class="row m-2 text-center">
          <h1>Dieta</h1>
        </div>
        <div class="row d-flex justify-content-center">
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="card">
                    <img src="<?php echo e(asset('storage/img/recipes/'.$recipe->image)); ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($recipe->offers->title); ?></h5>
                        <p class="card-text"><?php echo e($recipe->offers->breakfast); ?></p>
                    </div>
                </div>
            </div>
        </div>
      </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-pk1E90Hszlw5EECMfTb/NwRQwFnCSdBsgBtXoZh0+ajMQ5eMf0D0xH9pZdz+7j2" crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/recipes/main.blade.php ENDPATH**/ ?>