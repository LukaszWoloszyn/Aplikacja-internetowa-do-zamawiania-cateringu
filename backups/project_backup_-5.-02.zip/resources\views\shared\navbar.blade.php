<nav class="navbar navbar-expand-lg nav-bg">
    <div class="container-fluid">
      <a class="navbar-brand" href="{{route('home')}}">Catering dietetyczny</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link" href="{{route('home')}}">Start</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="{{route('recip')}}">Przepisy</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="{{route('main1')}}">Diety</a>
          </li>

          @if (Auth::check() && Auth::user()->admin)
          {{-- <li class="nav-item">
              <a class="nav-link" href="{{route('order')}}">Zamówienia</a>
          </li> --}}
            <li class="nav-item">
            <a class="nav-link" href="{{route('admin.offers.edit')}}">Edytuj</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{route('admin.offers.index')}}">Usuń</a>
            </li>
          @endif

          @guest
          @else
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('orders.index')}}">Zamówienia</a>
                    </li>
        @endguest

        {{-- <li class="nav-item">
            <a class="nav-link" href="{{route('admin.users.create')}}">Zarejestruj</a>
        </li> --}}
        </ul>
        <ul class="navbar-nav mb-2 mb-lg-0">
            <ul class="navbar-nav ml-auto">
                @guest
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login.form') }}">Zaloguj się</a>
                    </li>
                @else
                {{-- <li class="nav-item">
                    <a class="nav-link" href="{{route('orders.index')}}">Zamówienia</a>
                </li> --}}
                    <li class="nav-item">
                        <a class="nav-link" href="#">{{ Auth::user()->name }}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Wyloguj się
                        </a>
                    </li>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                @endguest
            </ul>
            {{-- @if (Auth::check())
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('logout') }}">{{ Auth::user()->name }}, wyloguj się... </a>
                </li>
            @else
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('login.authenticate') }}">Zaloguj się...</a>
                </li>
            @endif --}}
        </ul>
      </div>
    </div>
  </nav>
