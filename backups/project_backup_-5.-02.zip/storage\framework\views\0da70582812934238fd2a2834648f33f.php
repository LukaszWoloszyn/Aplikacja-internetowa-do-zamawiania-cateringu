<?php echo $__env->make('shared.head', ['pageTitle' => 'Edytuj Oferty'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div id="wycieczki" class="container mt-5 mb-5">
      <div class="row m-2 text-center">
        <h1>Edytuj Danie:</h1>
      </div>
      <div class="row d-flex justify-content-center">
          <div class="col-12 col-sm-6 col-lg-5">
              <div class="card">
                  <img src="<?php echo e(asset('storage/img/offer/'.$offer->image)); ?>" class="card-img-top">
                  <div class="card-body">
                      <h5 class="card-title"><?php echo e($offer->title); ?></h5>
                      <p class="card-text"><?php echo e($offer->breakfast); ?></p>
                      <p class="card-text"><?php echo e($offer->lunch); ?></p>
                      <p class="card-text"><?php echo e($offer->dinner); ?></p>
                      <p class="card-text"><?php echo e($offer->tea); ?></p>
                      <p class="card-text"><?php echo e($offer->supper); ?></p>

                      <!-- Formularz edycji -->
                      <form action="<?php echo e(route('admin.offers.update', $offer->id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('PUT'); ?>
                          <div class="form-group">
                              <label for="title">Tytuł</label>
                              <input type="text" name="title" class="form-control" value="<?php echo e($offer->title); ?>">
                          </div>
                          <div class="form-group">
                              <label for="breakfast">Śniadanie</label>
                              <input type="text" name="breakfast" class="form-control" value="<?php echo e($offer->breakfast); ?>">
                          </div>
                          <div class="form-group">
                              <label for="lunch">Lunch</label>
                              <input type="text" name="lunch" class="form-control" value="<?php echo e($offer->lunch); ?>">
                          </div>
                          <div class="form-group">
                              <label for="dinner">Obiad</label>
                              <input type="text" name="dinner" class="form-control" value="<?php echo e($offer->dinner); ?>">
                          </div>
                          <div class="form-group">
                              <label for="tea">Podwieczorek</label>
                              <input type="text" name="tea" class="form-control" value="<?php echo e($offer->tea); ?>">
                          </div>
                          <div class="form-group">
                              <label for="supper">Kolacja</label>
                              <input type="text" name="supper" class="form-control" value="<?php echo e($offer->supper); ?>">
                          </div>
                          <div class="form-group">
                              <label for="image">Nazwa Pliku Obrazu</label>
                              <input type="text" name="image" class="form-control" value="<?php echo e($offer->image); ?>">
                          </div>
                          <button type="submit" class="btn btn-primary mt-3">Zaktualizuj</button>
                      </form>
                  </div>
              </div>
          </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <th scope="row" colspan="6">Brak przepisów</th>
  <?php endif; ?>
  <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/admin/updateOff.blade.php ENDPATH**/ ?>