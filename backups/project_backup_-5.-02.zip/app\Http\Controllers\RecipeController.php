<?php

namespace App\Http\Controllers;

use App\Models\Offer;
use App\Models\Recipe;
use Illuminate\Http\Request;

class RecipeController extends Controller
{
    public function main1() {
        $recipes = Recipe::all();
        return view('recipes.main1', ['recipes' => $recipes]);
    }
    public function recip() {
        $recipes = Recipe::all();
        return view('recipes.recip', ['recipes' => $recipes]);
    }

    public function main($id)
    {
        // $recipes = Recipe::all($id);

        return view('recipes.main', [
            'recipe' =>  Recipe::findOrFail($id)
        ]);
    }


    // public function show($id)
    // {
    //      $recipes = Recipe::with('offers')->find($id);
    //      $recipes = Recipe::findOrFail($id);
    //      return view('recipes.show', ['recipes' => $recipes]);
    // }
}
