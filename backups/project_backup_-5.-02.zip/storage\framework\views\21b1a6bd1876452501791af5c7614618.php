<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('shared.head', ['pageTitle' => 'Dodaj nowy kraj'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container mt-5 mb-5">

        <?php echo $__env->make('shared.session-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row mt-4 mb-4 text-center">
            <h1>Dodaj nowy kraj</h1>
        </div>

        <?php echo $__env->make('shared.validation-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="<?php echo e(route('admin.storeOff')); ?>" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-2">
                        <label for="title" class="form-label">Nazwa</label>
                        <input id="title" name="title" type="text" class="form-control <?php if($errors->first('title')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('title')); ?>">
                        <div class="invalid-feedback">Nieprawidłowa nazwa!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="breakfast" class="form-label">Sniadanie</label>
                        <input id="breakfast" name="breakfast" type="text" class="form-control <?php if($errors->first('breakfast')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('breakfast')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="lunch" class="form-label">Lunch</label>
                        <input id="lunch" name="lunch" type="text" class="form-control <?php if($errors->first('lunch')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('lunch')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="dinner" class="form-label">dinner</label>
                        <input id="dinner" name="dinner" type="text" class="form-control <?php if($errors->first('dinner')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('dinner')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="tea" class="form-label">tea</label>
                        <input id="tea" name="tea" type="text" class="form-control <?php if($errors->first('tea')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('tea')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="supper" class="form-label">supper</label>
                        <input id="supper" name="supper" type="text" class="form-control <?php if($errors->first('supper')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('supper')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="image" class="form-label">image</label>
                        <input id="image" name="image" type="text" class="form-control <?php if($errors->first('image')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('image')); ?>">
                        <div class="invalid-feedback">Nieprawidłowy kod!</div>
                    </div>
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-success" type="submit" value="Wyślij">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/admin/createOff.blade.php ENDPATH**/ ?>