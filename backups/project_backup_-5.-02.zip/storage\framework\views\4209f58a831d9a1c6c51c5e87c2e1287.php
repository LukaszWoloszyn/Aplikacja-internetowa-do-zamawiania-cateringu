<?php if(session('error')): ?>
<div class="row d-flex justify-content-center">
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/shared/session-error.blade.php ENDPATH**/ ?>