@include('shared.html')

  @include('shared.head', ['pageTitle' => 'Panel admina'])
  <body>
    @include('shared.navbar')
<div id="cennik" class="container mt-5 mb-5">
    <div class="row">
        <h1>Tabela zamówień</h1>
    </div>
    <div class="table-responsive-sm">
      <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th scope="col">ID zamówienia</th>
                <th scope="col">Imię</th>
                <th scope="col">Nazwisko</th>
                <th scope="col">Email</th>
                <th scope="col">Numer telefonu</th>
                <th scope="col">Adres</th>
                {{-- <th scope="col">Dostawa</th> --}}
            </tr>
        </thead>
        <tbody>
          @forelse ($orders as $order)
              <tr>
                   <th scope="row">{{$order->id}}</th>
                   <td>{{$order->name}}</td>
                   <td>{{$order->last_name}}</td>
                   <td>{{$order->email}}</td>
                   <td>{{$order->phone_number}}</td>
                   <td>{{$order->address}}</td>
              </tr>
          @empty
              <tr>
                  <th scope="row" colspan="6">Brak wycieczek.</th>
               </tr>
          @endforelse
        </tbody>
    </table>
    </div>
  </div>

  {{-- @include('shared.footer') --}}

  </html>
