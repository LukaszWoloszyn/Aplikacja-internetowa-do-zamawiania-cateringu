<footer class="container-fluid nav-bg">
    <div class="row text-center pt-2">
        <p>&copy; Wycieczki górskie &ndash; 2024</p>
    </div>
  </footer>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/shared/footer.blade.php ENDPATH**/ ?>