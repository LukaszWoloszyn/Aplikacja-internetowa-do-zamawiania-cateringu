<?php echo $__env->make('shared.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('shared.head', ['pageTitle' => 'Nasz Catering'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    


    <div id="start">
        <div id="carouselExampleCaptions" class="carousel slide">
            <div class="carousel-inner">
                <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="carousel-item <?php if($loop->first): ?> active <?php endif; ?>">
                        <div class="container mt-5 mb-5">
                            <div class="row justify-content-center">
                                <div class="col-12 col-sm-6 col-lg-4 mb-4">
                                    <div class="card1">
                                        <img src="<?php echo e(asset('storage/img/offer/'.$offer->image)); ?>" class="card-img-top">
                                        <div class="card-body d-flex flex-column">
                                            <h5 class="card-title"><?php echo e($offer->title); ?></h5>
                                            <p class="card-text"><b>Śniadanie: </b><?php echo e($offer->breakfast); ?></p>
                                            <p class="card-text"><b>Lunch: </b><?php echo e($offer->lunch); ?></p>
                                            <p class="card-text"><?php echo e($offer->dinner); ?></p>
                                            <p class="card-text"><?php echo e($offer->tea); ?></p>
                                            <p class="card-text"><?php echo e($offer->supper); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <th scope="row" colspan="6">Brak ofert</th>
                <?php endif; ?>
            </div>
            <button class="carousel-control-prev1" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next1" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\Users\Łukasz\Desktop\studia\AI1\Projekt\Catering\Catering\resources\views/recipes/main1.blade.php ENDPATH**/ ?>