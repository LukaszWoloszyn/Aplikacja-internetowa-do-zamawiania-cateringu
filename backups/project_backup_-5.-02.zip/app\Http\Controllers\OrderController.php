<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\User;
use App\Models\Offer;
use Carbon\Carbon;

class OrderController extends Controller
{

    public function index()
    {
        $user = auth()->user();
        if ($user instanceof User && $user->isAdmin()) {
            $orders = Order::with('user', 'offer')->get();
        } else {
            $orders = Order::with('user', 'offer')->where('user_id', auth()->id())->get();
        }
        return view('orders.index', compact('orders'));
    }

    public function create($offer_id = null)
    {
        $user = auth()->user();
        if ($user instanceof User && $user->isAdmin()) {
            return redirect()->route('orders.index')->with('error', 'Administratorzy nie mogą składać zamówień');
        }

        // $offers = Offer::all();
        // return view('orders.create', compact('offers'));
        $offers = Offer::all();
        $selectedOffer = $offer_id ? Offer::find($offer_id) : null;
        return view('orders.create', compact('offers', 'selectedOffer'));
    }

    public function store(Request $request)
    {


        $request->validate([
            'offer_id' => 'required|exists:offers,id',
            'duration' => 'required|in:week,month',
        ]);

        $offer = Offer::find($request->offer_id);
        $startDate = Carbon::now();
        $endDate = $request->duration == 'week' ? $startDate->copy()->addWeek() : $startDate->copy()->addMonth();
        $totalPrice = $request->duration == 'week' ? $offer->price_month : $offer->price * 30;

        Order::create([
            'user_id' => auth()->id(),
            'offer_id' => $request->offer_id,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'total_price' => $totalPrice,
        ]);

        return redirect()->route('orders.index')->with('success', 'Zamówienie zostało utworzone');
    }
}


